﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NewWaterFallAdaptive
{
    public class User
    {
        public string RequestOptions { get; set; }

        public string SiteName { get; set; }

        public string SiteTemplate { get; set; }

        public string ParentSiteURL { get; set; }

        public string ExpectedStartDate { get; set; }

        public string SiteOwner { get; set; }

        public string SiteDescription { get; set; }

        public string AdditionalSiteOwner { get; set; }

        public string BusinessJustification { get; set; }

        public string TeamName { get; set; }

        public string TeamOwner { get; set; }

        public string TeamDescription { get; set; }

        public string TeamAccessType { get; set; }

        public string TeamDuration { get; set; }

        public string MailboxEmail { get; set; }

        public string OperationType { get; set; }

        public string LitigationOperationType { get; set; }

        public string LitigationDuration { get; set; }

        public string UserEmail { get; set; }

        public string OOOReplyText { get; set; }

        public string Feedback { get; set; }

        public string EmailId { get; set; }

        public string GroupMailboxDisplayName { get; set; }

        public string GroupMailboxEmailAddress { get; set; }

        public string GroupMailboxOwner { get; set; }

        public string ListofUsers { get; set; }

        public string AccessType { get; set; }

        public string AddOrRemove { get; set; }

        /// <summary>
        /// Mailbox Access Form Variables
        /// </summary>

        public string AddOrRemoveFromMailboxAccess { get; set; }

        public string MailboxAccessMailboxEmail { get; set; }

        public string MailboxAccessEmailAddress { get; set; }

        public string MailboxAccessTypeOfAccess { get; set; }

        public string MailboxAccessBusinessJustification { get; set; }

        public string Intent { get; set; }

        public string Entity { get; set; }

        public string CourseName { get; set; }

        public string Location { get; set; }

        public string Mode { get; set; }

        public DateTime DateTime { get; set; }

        ///Feedback Variables
        ///
        public string FeedbackOptions { get; set; }

        public string UserFeedback { get; set; }
        public string UserEmailID { get; set; }
        ///License Variables
        ///
        public string LicenseRequest { get; set; }
        public string LicenseEmailID { get; set; }
        public string LicenseToAdd { get; set; }
        public string LicenseToRemove { get; set; }
        //public string LicenseRequest { get; set; }

        public string ServiceNowSiteURL { get; set; }

        public string ServiceNowDescription { get; set; }


    }
}
