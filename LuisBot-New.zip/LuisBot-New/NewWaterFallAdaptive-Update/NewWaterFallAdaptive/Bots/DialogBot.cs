// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
//
// Generated with Bot Builder V4 SDK Template for Visual Studio CoreBot v4.3.0

using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Schema;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NewWaterFallAdaptive.Dialogs;

namespace NewWaterFallAdaptive.Bots
{
    // This IBot implementation can run any type of Dialog. The use of type parameterization is to allows multiple different bots
    // to be run at different endpoints within the same project. This can be achieved by defining distinct Controller types
    // each with dependency on distinct IBot types, this way ASP Dependency Injection can glue everything together without ambiguity.
    // The ConversationState is used by the Dialog system. The UserState isn't, however, it might have been used in a Dialog implementation,
    // and the requirement is that all BotState objects are saved at the end of a turn.
    public class DialogBot<T> : ActivityHandler where T : Dialog
    {
        protected readonly Dialog Dialog;
        protected readonly BotState ConversationState;
        protected readonly BotState UserState;
        protected readonly ILogger Logger;

        public DialogBot(ConversationState conversationState, UserState userState, T dialog, ILogger<DialogBot<T>> logger)
        {
            ConversationState = conversationState;
            UserState = userState;
            Dialog = dialog;
            Logger = logger;
        }

        public override async Task OnTurnAsync(ITurnContext turnContext, CancellationToken cancellationToken = default(CancellationToken))
        {
            await base.OnTurnAsync(turnContext, cancellationToken);
            var activity = turnContext.Activity;

            if (string.IsNullOrWhiteSpace(activity.Text) && activity.Value != null)
            //if (string.IsNullOrWhiteSpace(activity.Text))
            {
                activity.Text = JsonConvert.SerializeObject(activity.Text);
            }

            
            //switch (activity.Text)
            //{
            //    case "Search Training":
            //        await turnContext.SendActivityAsync(activity.Text);
            //        break;
            //    case "Get QnA Help":
            //       // var msg = $"Platform Assistance";
            //       // await turnContext.SendActivityAsync(MessageFactory.Text(msg), cancellationToken);
            //        var welcomeCard = CreateAdaptiveCardAttachment();
            //        var response = CreateResponse(turnContext.Activity, welcomeCard);
            //        await turnContext.SendActivityAsync(response, cancellationToken);
            //        //var response = CreateResponse(turnContext.Activity, welcomeCard);
            //        break;
            //    case "ServiceNow Ticket":
            //        var serviceNowCard = CreateServiceNowCardAttachment();
            //        var serviceNowResponse = CreateResponse(turnContext.Activity, serviceNowCard);
            //        await turnContext.SendActivityAsync(serviceNowResponse, cancellationToken);
            //        //await stepContext.Context.SendActivityAsync(message, cancellationToken);
            //        break;
            //}
           // await turnContext.SendActivityAsync(activity, cancellationToken);
            // Save any state changes that might have occured during the turn.
            await ConversationState.SaveChangesAsync(turnContext, false, cancellationToken);
            await UserState.SaveChangesAsync(turnContext, false, cancellationToken);
        }
        private Activity CreateResponse(IActivity activity, Attachment attachment)
        {
            var response = ((Activity)activity).CreateReply();
            response.Attachments = new List<Attachment>() { attachment };
            return response;
        }
        private Attachment CreateAdaptiveCardAttachment()
        {
            var adaptiveCard = "";
            // combine path for cross platform support
            try
            {
                string[] paths = { ".", "Cards", "2.json" };
                string fullPath = Path.Combine(paths);
                adaptiveCard = File.ReadAllText(fullPath);
            }
            catch(Exception ex)
            {

            }
            return new Attachment()
            {
                ContentType = "application/vnd.microsoft.card.adaptive",
                Content = JsonConvert.DeserializeObject(adaptiveCard),
            };
        }

        private Attachment CreateServiceNowCardAttachment()
        {
            var adaptiveCard = "";
            // combine path for cross platform support
            try
            {
                string[] paths = { ".", "Cards", "3.json" };
                string fullPath = Path.Combine(paths);
                adaptiveCard = File.ReadAllText(fullPath);
            }
            catch (Exception ex)
            {

            }
            return new Attachment()
            {
                ContentType = "application/vnd.microsoft.card.adaptive",
                Content = JsonConvert.DeserializeObject(adaptiveCard),
            };
        }
        protected override async Task OnMessageActivityAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            Logger.LogInformation("Running dialog with Message Activity.");

            // Run the Dialog with the new message Activity.
            await Dialog.Run(turnContext, ConversationState.CreateProperty<DialogState>("DialogState"), cancellationToken);
        }
    }
}
