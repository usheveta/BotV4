﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Dialogs.Choices;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace NewWaterFallAdaptive.Dialogs
{
    public class CreateTeamForm : ComponentDialog
    {
        private readonly IStatePropertyAccessor<User> _userAccessor;
        public CreateTeamForm(UserState userState) : base(nameof(CreateTeamForm))
        {
            _userAccessor = userState.CreateProperty<User>("User");

            var waterfallSteps = new WaterfallStep[]
            {
                //ConfirmRequestAsync,
                TeamNameAsync,
                TeamOwnerAsync,
                TeamDescriptionAsync,
                TeamDurationAsync,
                TeamAccessTypeAsync,
                ConfirmStepAsync,
                SummaryStepAsync,
            };

            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), waterfallSteps));
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new NumberPrompt<int>(nameof(NumberPrompt<int>)));
            AddDialog(new ChoicePrompt(nameof(ChoicePrompt)));
            AddDialog(new ConfirmPrompt(nameof(ConfirmPrompt)));

            InitialDialogId = nameof(WaterfallDialog);
        }

        private static async Task<DialogTurnResult> ConfirmRequestAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            return await stepContext.PromptAsync(nameof(ConfirmPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Do you want to create a site collection with following parameters: ")
            }, cancellationToken);
        }

        private static async Task<DialogTurnResult> TeamNameAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            //if ((bool)stepContext.Result)
            //{
            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Please provide Team Name.")
            }, cancellationToken);
            // }
            // else
            // {
            //     await stepContext.Context.SendActivityAsync(MessageFactory.Text("Thank you for using."));
            //     return await stepContext.EndDialogAsync(cancellationToken: cancellationToken);
            // }

        }

        private static async Task<DialogTurnResult> TeamOwnerAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["TeamName"] = (string)stepContext.Result;

            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Please provide Team Owner.")
            }, cancellationToken);
        }

        private static async Task<DialogTurnResult> TeamDescriptionAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["TeamOwner"] = (string)stepContext.Result;

            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Please provide Team Description.")
            }, cancellationToken);
        }

        private static async Task<DialogTurnResult> TeamDurationAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["TeamDescription"] = (string)stepContext.Result;

            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Please provide Team Duration.")
            }, cancellationToken);
        }

        private static async Task<DialogTurnResult> TeamAccessTypeAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["TeamDuration"] = (string)stepContext.Result;

            return await stepContext.PromptAsync(nameof(ChoicePrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Please select the Type of Access."),
                Choices = ChoiceFactory.ToChoices(new List<string> { "Private", "Public" }),
            }, cancellationToken);
        }
        private static async Task<DialogTurnResult> ConfirmStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["TeamAccessType"] = ((FoundChoice)stepContext.Result).Value;
            //var user = await _userAccessor.GetAsync(stepContext.Context, () => new User(), cancellationToken);
            var requestDetails = "";
            requestDetails = "Do you want to create new MS Team with following parameters: ";
            requestDetails = requestDetails + Environment.NewLine + "Team Name: " + stepContext.Values["TeamName"];
            requestDetails = requestDetails + Environment.NewLine + "Team Owner: " + stepContext.Values["TeamOwner"];
            requestDetails = requestDetails + Environment.NewLine + "Team Description: " + stepContext.Values["TeamDescription"];
            requestDetails = requestDetails + Environment.NewLine + "Team Duration: " + stepContext.Values["TeamDuration"];
            requestDetails = requestDetails + Environment.NewLine + "Team Access Type: " + stepContext.Values["TeamAccessType"];
            requestDetails = requestDetails + Environment.NewLine;
            return await stepContext.PromptAsync(nameof(ConfirmPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text(requestDetails + "Would you like to Confirm?")
            }, cancellationToken);
        }

        private async Task<DialogTurnResult> SummaryStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if ((bool)stepContext.Result)
            {
                var user = await _userAccessor.GetAsync(stepContext.Context, () => new User(), cancellationToken);
                
                user.TeamName = (string)stepContext.Values["TeamName"];
                user.TeamOwner = (string)stepContext.Values["TeamOwner"];
                user.TeamDescription = (string)stepContext.Values["TeamDescription"];
                user.TeamDuration = (string)stepContext.Values["TeamDuration"];
                user.TeamAccessType = (string)stepContext.Values["TeamAccessType"];

                var msg = user.TeamName + user.TeamOwner + user.TeamDescription + user.TeamDuration + user.TeamAccessType;


                
                return await stepContext.EndDialogAsync(user, cancellationToken);


            }
            else
            {
                await stepContext.Context.SendActivityAsync(MessageFactory.Text("Something went wrong. Try again later."));
                return await stepContext.EndDialogAsync(cancellationToken: cancellationToken);
            }
            //return await stepContext.NextAsync(user, cancellationToken);
        }
    }
}
